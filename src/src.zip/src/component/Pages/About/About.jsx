import React from "react";

const About = () => {
  return <div className="body1">About Component</div>;
};

export default About;
