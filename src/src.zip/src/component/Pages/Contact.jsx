import React, { useContext } from "react";
import { UserContext } from "../../Context";

function Contact() {
  const user = useContext(UserContext);
  return (
    <div>
      <h1>Contact Component</h1>
      <h3>hello, i'm {user} in my contact component</h3>
    </div>
  );
}

export default Contact;
