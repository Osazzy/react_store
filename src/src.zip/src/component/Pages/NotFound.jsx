import React from "react";

function NotFound() {
  return (
    <div>
      <h1>Page not Found</h1>
    </div>
  );
}

export default NotFound;
