import React from "react";

function Footer() {
  return (
    <div>
      <p>Designed by codeWithSas</p>
    </div>
  );
}

export default Footer;
