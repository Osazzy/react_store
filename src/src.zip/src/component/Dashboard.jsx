import React, { useContext, useState } from "react";
import { FaTrash } from "react-icons/fa";
import { UserContext } from "../Context";

function Dashboard() {
  const [popUp, setPopUp] = useState(false);
  const user = useContext(UserContext);
  const togglePopUp = () => {
    setPopUp((prev) => !prev);
  };

  const deleteAccount = () => {
    localStorage.clear();
    window.location.reload();
  };
  const name = localStorage.getItem("name");
  return (
    <div>
      <h1>Welcome {user}</h1>
      <div className="flex">
        <div className="btn">
          <button onClick={togglePopUp}>Deactivate Account</button>
        </div>

        {popUp ? (
          <div className="popup">
            <div className="pop">
              <h6>Are you sure you want to delete your account?</h6>
              <div className="bt">
                <button onClick={deleteAccount}>Yes</button>
                <button onClick={togglePopUp}>No</button>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
}

export default Dashboard;
