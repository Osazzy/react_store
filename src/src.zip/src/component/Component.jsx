import React, { useContext, useState } from "react";
import { UserContext } from "../Context";

function Component() {
  //   const [user, setUser] = useState("Jesse Hall");
  const user = useContext(UserContext);
  return (
    <div>
      <h1>{`Hello ${user}!`}</h1>
      <Component5 />
    </div>
  );
}

const Component2 = ({ user }) => {
  return (
    <>
      <h1>{`Hello ${user}!`}</h1>
    </>
  );
};
const Component3 = () => {
  return (
    <>
      <h1>{`Hello ${user}!`}</h1>
    </>
  );
};
const Component4 = () => {
  return (
    <>
      <h1>{`Hello ${user}!`}</h1>
    </>
  );
};
const Component5 = () => {
  const user = useContext(UserContext);
  return (
    <>
      <h1>{`Hello ${user}!`}</h1>
    </>
  );
};

export default Component;
