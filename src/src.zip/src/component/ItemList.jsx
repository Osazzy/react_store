import React from "react";

function ItemList({ name }) {
  return (
    <div>
      <h1>{name}</h1>
    </div>
  );
}

export default ItemList;
